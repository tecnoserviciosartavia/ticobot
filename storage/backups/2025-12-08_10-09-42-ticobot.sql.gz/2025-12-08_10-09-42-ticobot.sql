-- MySQL dump 10.13  Distrib 8.0.43, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: ticobot
-- ------------------------------------------------------
-- Server version	8.0.43-0ubuntu0.24.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `app_settings`
--

DROP TABLE IF EXISTS `app_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `app_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_settings`
--

LOCK TABLES `app_settings` WRITE;
/*!40000 ALTER TABLE `app_settings` DISABLE KEYS */;
INSERT INTO `app_settings` VALUES (1,'payment_contact','88525881',NULL,'2025-11-15 20:21:12','2025-11-15 20:34:00'),(2,'bank_accounts','BCR: CR21015202001214583670\nBAC: CR27010200009456644981\nPOPULAR: CR54016111152151714031\nBCT: CR56010730101104454585\nCOOPENAE: CR84081400011024939855\nMUTUAL ALAJUELA: CR98080348100999887871',NULL,'2025-11-15 20:21:13','2025-11-20 15:55:39'),(3,'service_name','TicoCast',NULL,'2025-11-15 20:21:13','2025-11-15 20:34:00'),(4,'beneficiary_name','Fabián Artavia Serrano',NULL,'2025-11-15 20:21:13','2025-11-15 20:34:00');
/*!40000 ALTER TABLE `app_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bot_menus`
--

DROP TABLE IF EXISTS `bot_menus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bot_menus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `keyword` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reply_message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` json DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `bot_menus_keyword_unique` (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bot_menus`
--

LOCK TABLES `bot_menus` WRITE;
/*!40000 ALTER TABLE `bot_menus` DISABLE KEYS */;
/*!40000 ALTER TABLE `bot_menus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clients`
--

DROP TABLE IF EXISTS `clients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `metadata` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=83 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clients`
--

LOCK TABLES `clients` WRITE;
/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES (1,'Cliente de Prueba','test_50672140974@test.com','50672140974','active',NULL,NULL,'2025-11-01 21:20:38','2025-11-01 20:14:07','2025-11-01 20:14:07'),(2,'fabian artavia',NULL,'72140974','active',NULL,NULL,'2025-11-02 23:16:10','2025-11-02 21:00:36','2025-11-02 21:00:36'),(3,'fabian artavia',NULL,'72140974','active',NULL,NULL,'2025-11-02 21:23:48','2025-11-20 13:14:07','2025-11-20 13:14:07'),(4,'prueba',NULL,'61784023','active',NULL,NULL,'2025-11-04 21:02:39','2025-11-20 13:14:07','2025-11-20 13:14:07'),(5,'fabian artavia',NULL,'72140974','active',NULL,NULL,'2025-11-04 21:50:09','2025-11-20 13:14:07','2025-11-20 13:14:07'),(6,'50671445572',NULL,'50671445572','active',NULL,NULL,'2025-11-16 12:30:00','2025-11-20 13:14:07','2025-11-20 13:14:07'),(7,'Leandro Orozco',NULL,'50670430715','active',NULL,NULL,'2025-11-16 13:23:31','2025-11-20 13:14:07','2025-11-20 13:14:07'),(8,'50687517324',NULL,'50687517324','active',NULL,NULL,'2025-11-17 08:04:54','2025-11-20 13:14:07','2025-11-20 13:14:07'),(9,'50663096800',NULL,'50663096800','active',NULL,NULL,'2025-11-17 17:37:14','2025-11-20 13:14:07','2025-11-20 13:14:07'),(10,'50672707228',NULL,'50672707228','active',NULL,NULL,'2025-11-18 07:03:57','2025-11-20 13:14:07','2025-11-20 13:14:07'),(11,'50687502916',NULL,'50687502916','active',NULL,NULL,'2025-11-18 09:55:01','2025-11-20 13:14:07','2025-11-20 13:14:07'),(12,'50662653781',NULL,'50662653781','active',NULL,NULL,'2025-11-18 14:36:06','2025-11-20 13:14:07','2025-11-20 13:14:07'),(13,'50683325462',NULL,'50683325462','active',NULL,NULL,'2025-11-18 19:16:07','2025-11-20 13:14:07','2025-11-20 13:14:07'),(14,'50661322578',NULL,'50661322578','active',NULL,NULL,'2025-11-18 19:21:20','2025-11-20 13:14:07','2025-11-20 13:14:07'),(15,'50662275278',NULL,'50662275278','active',NULL,NULL,'2025-11-18 21:58:08','2025-11-20 13:14:07','2025-11-20 13:14:07'),(16,'Luis Rey',NULL,'83413265','active',NULL,NULL,'2025-11-20 13:22:53','2025-11-20 14:51:08','2025-11-20 14:51:08'),(17,'Fabia Artavia',NULL,'72140974','active',NULL,NULL,'2025-11-20 14:29:01','2025-11-20 14:51:08','2025-11-20 14:51:08'),(18,'Aarón',NULL,'71663113','active',NULL,NULL,'2025-11-20 15:12:09','2025-11-20 16:09:37',NULL),(19,'Alexander Sandoval',NULL,'70302470','active',NULL,NULL,'2025-11-20 15:12:09','2025-11-20 16:09:37',NULL),(20,'Alvaro Arce',NULL,'72707228','active',NULL,NULL,'2025-11-20 15:12:09','2025-11-20 16:09:37',NULL),(21,'Andrés Bermudez',NULL,'83677150','active',NULL,NULL,'2025-11-20 15:12:09','2025-11-20 16:09:37',NULL),(22,'Armando Ramírez',NULL,'88974441','active',NULL,NULL,'2025-11-20 15:12:10','2025-11-20 16:09:38',NULL),(23,'Belkys Mejía',NULL,'62725541','active',NULL,NULL,'2025-11-20 15:12:10','2025-11-20 16:09:38',NULL),(24,'Bismarck Obando',NULL,'71626053','active',NULL,NULL,'2025-11-20 15:12:10','2025-11-20 16:09:38',NULL),(25,'Bryan Gómez',NULL,'87441073','active',NULL,NULL,'2025-11-20 15:12:10','2025-11-20 15:50:26','2025-11-20 15:50:26'),(26,'Carlos Fernández',NULL,'60263880','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(27,'Carlos Solis',NULL,'85782222','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(28,'Cati Solórzano Bákit',NULL,'83190842','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(29,'Cesar Barquero',NULL,'61088955','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(30,'Daniela Solano',NULL,'85096177','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(31,'Eduardo Morales',NULL,'83319122','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:39',NULL),(32,'Eduardo Salazar',NULL,'87517324','active',NULL,NULL,'2025-11-20 15:12:11','2025-11-20 16:09:40',NULL),(33,'Elizabeth',NULL,'83194147','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:40',NULL),(34,'Gerardo Bermudez',NULL,'70909539','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:40',NULL),(35,'Grettel',NULL,'61151082','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:40',NULL),(36,'Harry Solano',NULL,'71582729','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:40',NULL),(37,'Jaime Tortós',NULL,'70993915','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:40',NULL),(38,'Jonathan Garita',NULL,'61322578','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:41',NULL),(39,'Jonathan Prendas',NULL,'87502916','active',NULL,NULL,'2025-11-20 15:12:12','2025-11-20 16:09:41',NULL),(40,'Jorge Picado',NULL,'87127185','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:41',NULL),(41,'José Pablo Lobo',NULL,'86686768','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:41',NULL),(42,'Juan Carlos Cortés',NULL,'72057966','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:41',NULL),(43,'Karla Montenegro',NULL,'87144208','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:41',NULL),(44,'KAROO',NULL,'60244291','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:41',NULL),(45,'Krysti',NULL,'62321128','active',NULL,NULL,'2025-11-20 15:12:13','2025-11-20 16:09:42',NULL),(46,'Leandro Orozco',NULL,'70430715','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:42',NULL),(47,'Les',NULL,'60450895','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:42',NULL),(48,'Ludwing vega',NULL,'84693114','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:42',NULL),(49,'Luis Rey',NULL,'83413265','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:42',NULL),(50,'Maikol Espinoza',NULL,'85204903','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:42',NULL),(51,'Marce',NULL,'83325462','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:43',NULL),(52,'Maria Masis',NULL,'61708244','active',NULL,NULL,'2025-11-20 15:12:14','2025-11-20 16:09:43',NULL),(53,'Marilyn Vega',NULL,'84305295','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:44',NULL),(54,'María Hevia',NULL,'89272975','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:44',NULL),(55,'Mejía Eduarte',NULL,'62694160','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:44',NULL),(56,'Obed Mejía',NULL,'63096800','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:45',NULL),(57,'Orlando Villagra',NULL,'63120452','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:45',NULL),(58,'Pablo Vargas',NULL,'72457845','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:45',NULL),(59,'Pao',NULL,'89266167','active',NULL,NULL,'2025-11-20 15:12:15','2025-11-20 16:09:46',NULL),(60,'Pedro Cerna',NULL,'85028361','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:46',NULL),(61,'Raquel Zeledon',NULL,'70116071','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:46',NULL),(62,'Sofía Elizondo',NULL,'63810414','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:47',NULL),(63,'Steven Alfaro',NULL,'61183344','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:47',NULL),(64,'Steven Godinez',NULL,'85975395','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:47',NULL),(65,'Sunny Leiton',NULL,'87363800','active',NULL,NULL,'2025-11-20 15:12:16','2025-11-20 16:09:47',NULL),(66,'SUPER ASERRI',NULL,'64731851','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:47',NULL),(67,'Victor Hidalgo',NULL,'63423040','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:47',NULL),(68,'Victor Ángulo',NULL,'62275278','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:47',NULL),(69,'W@le',NULL,'71445572','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:48',NULL),(70,'Yadelith Mendoza',NULL,'60312134','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:48',NULL),(71,'Yanan Campos',NULL,'72007128','active',NULL,NULL,'2025-11-20 15:12:17','2025-11-20 16:09:48',NULL),(72,'Yeis Obando',NULL,'61788824','active',NULL,NULL,'2025-11-20 15:12:18','2025-11-20 16:09:48',NULL),(73,'Yendri Aguilar',NULL,'89516093','active',NULL,NULL,'2025-11-20 15:12:18','2025-11-20 16:09:48',NULL),(74,'Zenaida Galvez',NULL,'62805121','active',NULL,NULL,'2025-11-20 15:12:18','2025-11-20 16:09:48',NULL),(75,'Bryan Gómez',NULL,'87441073','active',NULL,NULL,'2025-11-20 15:36:29','2025-11-20 16:09:39',NULL),(76,'Fabian Artavia',NULL,'72140974','active',NULL,NULL,'2025-11-20 15:52:01','2025-11-20 15:56:11','2025-11-20 15:56:11'),(77,'Fabian Artavia',NULL,'72140974','active',NULL,NULL,'2025-11-20 15:57:38','2025-11-20 16:05:09','2025-11-20 16:05:09'),(78,'Fabian Artavia',NULL,'72140974','active',NULL,NULL,'2025-11-20 16:05:36','2025-11-20 16:07:40','2025-11-20 16:07:40'),(79,'Carlos Galeano',NULL,'72222362','active',NULL,NULL,'2025-11-21 14:52:22','2025-11-21 14:52:22',NULL),(80,'Gloria Paiba',NULL,'86325052','active',NULL,'Netflix compartido c7','2025-11-21 18:38:43','2025-11-21 18:40:07',NULL),(81,'Daniela',NULL,'63702319','active',NULL,NULL,'2025-11-25 18:01:56','2025-11-25 18:01:56',NULL),(82,'Ricardo LicOutlet',NULL,'50683387993','active',NULL,NULL,'2025-12-02 15:25:21','2025-12-02 15:26:09',NULL);
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conciliations`
--

DROP TABLE IF EXISTS `conciliations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `conciliations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint unsigned NOT NULL,
  `reviewed_by` bigint unsigned DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `verified_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `conciliations_payment_id_unique` (`payment_id`),
  KEY `conciliations_reviewed_by_foreign` (`reviewed_by`),
  CONSTRAINT `conciliations_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `conciliations_reviewed_by_foreign` FOREIGN KEY (`reviewed_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conciliations`
--

LOCK TABLES `conciliations` WRITE;
/*!40000 ALTER TABLE `conciliations` DISABLE KEYS */;
INSERT INTO `conciliations` VALUES (15,21,1,'approved',NULL,NULL,'2025-11-21 12:07:17','2025-11-21 12:07:17'),(16,22,1,'approved',NULL,NULL,'2025-11-21 17:50:31','2025-11-21 17:50:31'),(17,23,1,'approved',NULL,NULL,'2025-11-22 06:54:45','2025-11-22 06:54:45'),(18,24,1,'approved',NULL,NULL,'2025-11-22 06:54:57','2025-11-22 06:54:57'),(19,25,1,'approved',NULL,NULL,'2025-11-24 14:00:50','2025-11-24 14:00:50'),(20,26,1,'approved',NULL,NULL,'2025-11-24 23:49:31','2025-11-24 23:49:31'),(21,27,1,'approved',NULL,NULL,'2025-11-25 13:16:31','2025-11-25 13:16:31'),(22,28,1,'approved',NULL,NULL,'2025-11-26 18:03:34','2025-11-26 18:03:34'),(23,29,1,'approved',NULL,NULL,'2025-11-26 20:38:10','2025-11-26 20:38:10'),(24,30,1,'approved',NULL,NULL,'2025-11-27 16:44:41','2025-11-27 16:44:41'),(25,32,1,'approved',NULL,NULL,'2025-11-29 12:43:50','2025-11-29 12:43:50'),(26,33,1,'approved',NULL,NULL,'2025-11-29 12:44:02','2025-11-29 12:44:02'),(27,34,1,'approved',NULL,NULL,'2025-11-29 12:46:02','2025-11-29 12:46:02'),(28,35,1,'approved',NULL,NULL,'2025-11-29 22:55:50','2025-11-29 22:55:50'),(29,37,1,'approved',NULL,NULL,'2025-11-30 16:27:57','2025-11-30 16:27:57'),(30,38,1,'approved',NULL,NULL,'2025-11-30 20:01:44','2025-11-30 20:01:44'),(31,39,1,'approved',NULL,NULL,'2025-11-30 22:04:09','2025-11-30 22:04:09'),(32,40,1,'approved',NULL,NULL,'2025-12-01 00:39:06','2025-12-01 00:39:06'),(33,41,1,'approved',NULL,NULL,'2025-12-01 15:27:00','2025-12-01 15:27:00'),(34,42,1,'approved',NULL,NULL,'2025-12-01 15:43:33','2025-12-01 15:43:33'),(35,43,1,'approved',NULL,NULL,'2025-12-01 16:15:31','2025-12-01 16:15:31'),(36,44,1,'approved',NULL,NULL,'2025-12-02 14:29:32','2025-12-02 14:29:32'),(37,45,1,'approved',NULL,NULL,'2025-12-02 15:26:44','2025-12-02 15:26:44'),(38,46,1,'approved',NULL,NULL,'2025-12-03 02:52:25','2025-12-03 02:52:25'),(39,47,1,'approved',NULL,NULL,'2025-12-04 18:02:52','2025-12-04 18:02:52'),(40,48,1,'approved',NULL,NULL,'2025-12-06 01:26:35','2025-12-06 01:26:35'),(41,49,1,'approved',NULL,NULL,'2025-12-06 01:26:45','2025-12-06 01:26:45'),(42,50,1,'approved',NULL,NULL,'2025-12-07 19:31:19','2025-12-07 19:31:19'),(43,51,1,'approved',NULL,NULL,'2025-12-07 19:42:33','2025-12-07 19:42:33');
/*!40000 ALTER TABLE `conciliations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract_types`
--

DROP TABLE IF EXISTS `contract_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `default_message` text COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `contract_types_key_unique` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract_types`
--

LOCK TABLES `contract_types` WRITE;
/*!40000 ALTER TABLE `contract_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `contract_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contracts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CRC',
  `billing_cycle` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'monthly',
  `next_due_date` date DEFAULT NULL,
  `grace_period_days` tinyint unsigned NOT NULL DEFAULT '0',
  `metadata` json DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `contract_type_id` bigint unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contracts_client_id_foreign` (`client_id`),
  KEY `contracts_contract_type_id_foreign` (`contract_type_id`),
  CONSTRAINT `contracts_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contracts_contract_type_id_foreign` FOREIGN KEY (`contract_type_id`) REFERENCES `contract_types` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contracts`
--

LOCK TABLES `contracts` WRITE;
/*!40000 ALTER TABLE `contracts` DISABLE KEYS */;
INSERT INTO `contracts` VALUES (79,18,'TicoCast',7000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:10:53','2025-11-20 16:10:53',NULL,NULL),(80,19,'TicoCast',2000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:10:54','2025-12-04 17:46:37',NULL,NULL),(81,20,'TicoCast',2000.00,'CRC','monthly','2025-12-17',0,NULL,NULL,'2025-11-20 16:10:54','2025-11-20 16:10:54',NULL,NULL),(82,21,'TicoCast',2000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:10:55','2025-12-04 17:47:07',NULL,NULL),(83,22,'TicoCast',2000.00,'CRC','monthly','2026-01-05',0,NULL,NULL,'2025-11-20 16:10:56','2025-12-05 05:30:08',NULL,NULL),(84,23,'TicoCast',2000.00,'CRC','monthly','2025-12-12',0,NULL,NULL,'2025-11-20 16:10:56','2025-11-20 16:10:56',NULL,NULL),(85,24,'TicoCast',2000.00,'CRC','monthly','2025-12-16',0,NULL,NULL,'2025-11-20 16:10:56','2025-11-20 16:10:56',NULL,NULL),(86,75,'TicoCast',2000.00,'CRC','monthly','2025-12-26',0,NULL,NULL,'2025-11-20 16:10:57','2025-11-26 19:57:27',NULL,NULL),(87,26,'TicoCast',2000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:10:57','2025-11-20 16:10:57',NULL,NULL),(88,27,'TicoCast',2000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:10:57','2025-12-04 17:47:08',NULL,NULL),(89,28,'TicoFac',27000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:10:58','2025-11-20 16:10:58',NULL,NULL),(90,29,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:10:58','2025-11-30 05:30:03',NULL,NULL),(91,30,'TicoCast',3000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:10:58','2025-11-30 05:30:04',NULL,NULL),(92,31,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:10:59','2025-11-30 05:30:05',NULL,NULL),(93,32,'TicoCast',2000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:10:59','2025-11-20 16:10:59',NULL,NULL),(94,33,'TicoCast',5000.00,'CRC','monthly','2026-01-07',0,NULL,NULL,'2025-11-20 16:10:59','2025-12-07 05:30:10',NULL,NULL),(95,34,'TicoCast',5000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:11:00','2025-11-20 16:11:00',NULL,NULL),(96,35,'TicoCast',7000.00,'CRC','monthly','2026-01-03',0,NULL,NULL,'2025-11-20 16:11:00','2025-12-03 05:30:05',NULL,NULL),(97,36,'TicoCast',2000.00,'CRC','monthly','2025-12-29',0,NULL,NULL,'2025-11-20 16:11:00','2025-11-29 05:30:29',NULL,NULL),(98,37,'TicoCast',2000.00,'CRC','monthly','2025-12-10',0,NULL,NULL,'2025-11-20 16:11:00','2025-11-20 16:11:00',NULL,NULL),(99,38,'TicoCast',6000.00,'CRC','monthly','2025-12-18',0,NULL,NULL,'2025-11-20 16:11:01','2025-11-20 16:11:01',NULL,NULL),(100,39,'TicoCast',2000.00,'CRC','monthly','2025-12-21',0,NULL,NULL,'2025-11-20 16:11:01','2025-11-20 23:30:09',NULL,NULL),(101,40,'TicoCast',2000.00,'CRC','monthly','2025-12-25',0,NULL,NULL,'2025-11-20 16:11:01','2025-11-25 05:30:25',NULL,NULL),(102,41,'TicoCast',2000.00,'CRC','monthly','2025-12-26',0,NULL,NULL,'2025-11-20 16:11:02','2025-11-26 05:30:25',NULL,NULL),(103,42,'TicoCast',10000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:02','2025-12-04 17:47:39',NULL,NULL),(104,43,'TicoCast',2000.00,'CRC','monthly','2025-12-19',0,NULL,NULL,'2025-11-20 16:11:02','2025-11-20 16:11:02',NULL,NULL),(105,44,'TicoCast',5000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:02','2025-12-04 17:47:41',NULL,NULL),(106,45,'TicoCast',3000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:03','2025-12-04 17:47:42',NULL,NULL),(107,46,'TicoCast',2000.00,'CRC','monthly','2025-12-13',0,NULL,NULL,'2025-11-20 16:11:03','2025-11-20 16:11:03',NULL,NULL),(108,47,'TicoCast',10000.00,'CRC','monthly','2025-12-29',0,NULL,NULL,'2025-11-20 16:11:03','2025-11-29 05:30:31',NULL,NULL),(109,48,'TicoCast',2000.00,'CRC','monthly','2025-12-11',0,NULL,NULL,'2025-11-20 16:11:04','2025-11-20 16:11:04',NULL,NULL),(110,49,'TicoCast',2000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:04','2025-12-04 17:48:08',NULL,NULL),(111,50,'TicoCast',2000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:11:04','2025-11-20 16:11:04',NULL,NULL),(112,51,'TicoCast',7000.00,'CRC','monthly','2025-12-18',0,NULL,NULL,'2025-11-20 16:11:05','2025-11-20 16:11:05',NULL,NULL),(113,52,'TicoCast',3000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:05','2025-12-04 17:48:10',NULL,NULL),(114,53,'TicoCast',2000.00,'CRC','monthly','2025-12-22',0,NULL,NULL,'2025-11-20 16:11:05','2025-11-21 23:30:10',NULL,NULL),(115,54,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:11:06','2025-11-30 05:30:08',NULL,NULL),(116,55,'TicoCast',13000.00,'CRC','monthly','2025-12-19',0,NULL,NULL,'2025-11-20 16:11:06','2025-11-20 16:11:06',NULL,NULL),(117,56,'TicoCast',2000.00,'CRC','monthly','2025-12-17',0,NULL,NULL,'2025-11-20 16:11:06','2025-11-20 16:11:06',NULL,NULL),(118,57,'TicoCast',2000.00,'CRC','monthly','2026-01-02',0,NULL,NULL,'2025-11-20 16:11:07','2025-12-02 05:30:07',NULL,NULL),(119,58,'TicoCast',2000.00,'CRC','monthly','2025-12-24',0,NULL,NULL,'2025-11-20 16:11:07','2025-11-24 05:30:24',NULL,NULL),(120,59,'TicoCast',4000.00,'CRC','monthly','2026-01-05',0,NULL,NULL,'2025-11-20 16:11:08','2025-12-05 05:30:09',NULL,NULL),(121,60,'TicoCast',2000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-20 16:11:08','2025-12-04 17:48:12',NULL,NULL),(122,61,'TicoCast',3000.00,'CRC','monthly','2025-12-21',0,NULL,NULL,'2025-11-20 16:11:09','2025-11-20 23:30:10',NULL,NULL),(123,62,'TicoCast',4000.00,'CRC','monthly','2025-12-14',0,NULL,NULL,'2025-11-20 16:11:09','2025-11-21 12:06:38',NULL,NULL),(124,63,'TicoCast',6000.00,'CRC','monthly','2026-01-01',0,NULL,NULL,'2025-11-20 16:11:10','2025-12-01 05:30:04',NULL,NULL),(125,64,'TicoCast',2000.00,'CRC','monthly','2025-12-23',0,NULL,NULL,'2025-11-20 16:11:10','2025-11-22 23:30:11',NULL,NULL),(126,65,'TicoCast',2000.00,'CRC','monthly','2025-12-16',0,NULL,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL,NULL),(127,66,'TicoCast',50000.00,'CRC','monthly','2025-12-09',0,NULL,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL,NULL),(128,67,'TicoCast',2000.00,'CRC','monthly','2025-12-16',0,NULL,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL,NULL),(129,68,'TicoCast',2000.00,'CRC','monthly','2025-12-16',0,NULL,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL,NULL),(130,69,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:11:12','2025-11-30 05:30:09',NULL,NULL),(131,70,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:11:12','2025-11-30 20:03:02',NULL,NULL),(132,71,'TicoCast',2000.00,'CRC','monthly','2025-12-15',0,NULL,NULL,'2025-11-20 16:11:12','2025-11-20 16:11:12',NULL,NULL),(133,72,'TicoCast',2000.00,'CRC','monthly','2025-12-30',0,NULL,NULL,'2025-11-20 16:11:13','2025-11-30 05:30:10',NULL,NULL),(134,73,'TicoCast',2000.00,'CRC','monthly','2025-12-24',0,NULL,NULL,'2025-11-20 16:11:13','2025-11-24 05:30:26',NULL,NULL),(135,74,'TicoCast',4000.00,'CRC','monthly','2025-12-14',0,NULL,NULL,'2025-11-20 16:11:13','2025-11-20 16:11:13',NULL,NULL),(136,79,'TicoCast',2000.00,'CRC','monthly','2025-12-21',0,NULL,NULL,'2025-11-21 14:53:01','2025-11-21 14:53:06',NULL,NULL),(137,80,'TicoCast',3000.00,'CRC','monthly','2025-12-21',0,NULL,NULL,'2025-11-21 18:39:34','2025-11-21 18:39:34',NULL,NULL),(138,81,'TicoCast',3000.00,'CRC','monthly','2026-01-04',0,NULL,NULL,'2025-11-25 18:02:15','2025-12-04 17:48:13',NULL,NULL),(139,82,'TicoFac',20000.00,'CRC','monthly','2026-01-01',0,NULL,NULL,'2025-12-02 15:26:29','2025-12-02 15:26:29',NULL,NULL);
/*!40000 ALTER TABLE `contracts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2025_11_01_041002_create_clients_table',1),(5,'2025_11_01_041005_create_contracts_table',1),(6,'2025_11_01_041010_create_reminders_table',1),(7,'2025_11_01_041015_create_reminder_messages_table',1),(8,'2025_11_01_041025_create_payments_table',1),(9,'2025_11_01_041048_create_payment_receipts_table',1),(10,'2025_11_01_041053_create_conciliations_table',1),(11,'2025_11_01_042331_create_personal_access_tokens_table',1),(12,'2025_11_02_000001_create_contract_types_table',2),(13,'2025_11_02_000002_add_contract_type_id_to_contracts',2),(14,'2025_11_02_000003_create_bot_menus_table',2),(15,'2025_11_03_000000_drop_legal_id_from_clients_table',2),(16,'2025_11_15_000000_create_app_settings_table',3),(17,'2025_12_08_000000_add_notes_to_contracts_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_receipts`
--

DROP TABLE IF EXISTS `payment_receipts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_receipts` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `payment_id` bigint unsigned NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` bigint unsigned NOT NULL,
  `mime_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'application/pdf',
  `received_at` timestamp NULL DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_receipts_payment_id_foreign` (`payment_id`),
  CONSTRAINT `payment_receipts_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_receipts`
--

LOCK TABLES `payment_receipts` WRITE;
/*!40000 ALTER TABLE `payment_receipts` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment_receipts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint unsigned NOT NULL,
  `contract_id` bigint unsigned DEFAULT NULL,
  `reminder_id` bigint unsigned DEFAULT NULL,
  `amount` decimal(12,2) NOT NULL,
  `currency` varchar(3) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'CRC',
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unverified',
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual',
  `reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_at` date DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payments_client_id_foreign` (`client_id`),
  KEY `payments_contract_id_foreign` (`contract_id`),
  KEY `payments_reminder_id_foreign` (`reminder_id`),
  CONSTRAINT `payments_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `payments_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `payments_reminder_id_foreign` FOREIGN KEY (`reminder_id`) REFERENCES `reminders` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,4,NULL,NULL,8000.00,'CRC','verified','whatsapp','bot-test-50661784023',NULL,'{\"months\": 1, \"local_receipt_id\": \"test-local-50661784023\"}','2025-11-04 21:35:07','2025-11-20 13:14:05','2025-11-20 13:14:05'),(2,4,NULL,NULL,8000.00,'CRC','verified','whatsapp','bot-test-50661784023',NULL,'{\"months\": 1, \"local_receipt_id\": \"test-local-50661784023\"}','2025-11-04 21:35:11','2025-11-20 13:14:05','2025-11-20 13:14:05'),(3,6,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50671445572-1763317800070',NULL,'{\"local_receipt_id\": \"50671445572-1763317800070\"}','2025-11-16 12:30:00','2025-11-20 13:14:05','2025-11-20 13:14:05'),(4,7,NULL,NULL,0.00,'CRC','verified','whatsapp','bot:50670430715-1763321011290',NULL,'{\"months\": 1, \"local_receipt_id\": \"50670430715-1763321011290\", \"backend_receipt_id\": 4}','2025-11-16 13:23:31','2025-11-20 13:14:05','2025-11-20 13:14:05'),(5,8,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50687517324-1763388293683',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687517324-1763388293683\", \"backend_receipt_id\": 5}','2025-11-17 08:04:54','2025-11-20 13:14:05','2025-11-20 13:14:05'),(6,3,NULL,NULL,16000.00,'CRC','unverified','whatsapp','test-1763400103','2025-11-17','{\"test\": true, \"months\": 2, \"local_receipt_id\": \"50672140974-1763400103\"}','2025-11-17 11:21:43','2025-11-20 13:14:05','2025-11-20 13:14:05'),(7,3,NULL,NULL,0.00,'CRC','verified','whatsapp','test-modal-1763403183','2025-11-17','{\"months\": 2, \"test_modal\": true, \"local_receipt_id\": \"50672140974-1763403183\", \"calculated_amount\": 16000, \"conciliation_contract_id\": 8}','2025-11-17 12:13:03','2025-11-20 13:14:05','2025-11-20 13:14:05'),(8,3,NULL,NULL,0.00,'CRC','verified','whatsapp','TEST-1763405311','2025-11-17','{\"months\": 1, \"calculated_amount\": 8000, \"conciliation_contract_id\": 8}','2025-11-17 12:48:31','2025-11-20 13:14:05','2025-11-20 13:14:05'),(9,9,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50663096800-1763422634406',NULL,'{\"months\": 1, \"local_receipt_id\": \"50663096800-1763422634406\", \"backend_receipt_id\": 9}','2025-11-17 17:37:14','2025-11-20 13:14:05','2025-11-20 13:14:05'),(10,9,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50663096800-1763422741060',NULL,'{\"months\": 1, \"local_receipt_id\": \"50663096800-1763422741060\", \"backend_receipt_id\": 10}','2025-11-17 17:39:01','2025-11-20 13:14:05','2025-11-20 13:14:05'),(11,10,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50672707228-1763471037677',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672707228-1763471037677\", \"backend_receipt_id\": 11}','2025-11-18 07:03:58','2025-11-20 13:14:05','2025-11-20 13:14:05'),(12,11,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50687502916-1763481300825',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687502916-1763481300825\", \"backend_receipt_id\": 12}','2025-11-18 09:55:01','2025-11-20 13:14:05','2025-11-20 13:14:05'),(13,12,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50662653781-1763498165921',NULL,'{\"months\": 1, \"local_receipt_id\": \"50662653781-1763498165921\", \"backend_receipt_id\": 13}','2025-11-18 14:36:06','2025-11-20 13:14:05','2025-11-20 13:14:05'),(14,13,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50683325462-1763514966776',NULL,'{\"months\": 1, \"local_receipt_id\": \"50683325462-1763514966776\", \"backend_receipt_id\": 14}','2025-11-18 19:16:07','2025-11-20 13:14:05','2025-11-20 13:14:05'),(15,14,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50661322578-1763515280016',NULL,'{\"months\": 1, \"local_receipt_id\": \"50661322578-1763515280016\", \"backend_receipt_id\": 15}','2025-11-18 19:21:20','2025-11-20 13:14:05','2025-11-20 13:14:05'),(16,15,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50662275278-1763524687725',NULL,'{\"months\": 1, \"local_receipt_id\": \"50662275278-1763524687725\", \"backend_receipt_id\": 16}','2025-11-18 21:58:08','2025-11-20 13:14:05','2025-11-20 13:14:05'),(17,75,NULL,NULL,0.00,'CRC','unverified','whatsapp','bot:50687441073-1763674589645',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687441073-1763674589645\", \"backend_receipt_id\": 17}','2025-11-20 15:36:30','2025-11-20 15:50:26','2025-11-20 15:50:26'),(18,76,NULL,NULL,0.00,'CRC','verified','whatsapp','bot:50672140974-1763675600393',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672140974-1763675600393\", \"calculated_amount\": 1000, \"backend_receipt_id\": 18, \"conciliation_contract_id\": 76}','2025-11-20 15:53:21','2025-11-20 15:56:11','2025-11-20 15:56:11'),(19,77,NULL,NULL,0.00,'CRC','verified','whatsapp','bot:50672140974-1763675942232',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672140974-1763675942232\", \"calculated_amount\": 1000, \"backend_receipt_id\": 19, \"conciliation_contract_id\": 77}','2025-11-20 15:59:02','2025-11-20 16:05:09','2025-11-20 16:05:09'),(20,78,NULL,NULL,1000.00,'CRC','verified','whatsapp','bot:50672140974-1763676394815',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672140974-1763676394815\", \"calculated_amount\": 1000, \"backend_receipt_id\": 20, \"conciliation_contract_id\": 78}','2025-11-20 16:06:35','2025-11-20 16:07:40','2025-11-20 16:07:40'),(21,62,NULL,NULL,4000.00,'CRC','verified','whatsapp','bot:50663810414-1763748292797',NULL,'{\"months\": 1, \"local_receipt_id\": \"50663810414-1763748292797\", \"calculated_amount\": 4000, \"backend_receipt_id\": 21, \"conciliation_contract_id\": 123}','2025-11-21 12:04:53','2025-11-21 12:07:17',NULL),(22,61,NULL,NULL,3000.00,'CRC','verified','whatsapp','bot:50670116071-1763768306459',NULL,'{\"months\": 1, \"local_receipt_id\": \"50670116071-1763768306459\", \"calculated_amount\": 3000, \"backend_receipt_id\": 22, \"conciliation_contract_id\": 122}','2025-11-21 17:38:26','2025-11-21 17:50:32',NULL),(23,79,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50672222362-1763774996900',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672222362-1763774996900\", \"calculated_amount\": 2000, \"conciliation_contract_id\": 136}','2025-11-21 19:29:57','2025-11-22 06:54:45',NULL),(24,53,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50684305295-1763815249704',NULL,'{\"months\": 1, \"local_receipt_id\": \"50684305295-1763815249704\", \"calculated_amount\": 2000, \"conciliation_contract_id\": 114}','2025-11-22 06:40:50','2025-11-22 06:54:57',NULL),(25,73,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50689516093-1763992607031',NULL,'{\"months\": 1, \"local_receipt_id\": \"50689516093-1763992607031\", \"calculated_amount\": 2000, \"backend_receipt_id\": 25, \"conciliation_contract_id\": 134}','2025-11-24 13:56:49','2025-11-24 14:00:50',NULL),(26,64,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50685975395-1764015262161',NULL,'{\"months\": 1, \"local_receipt_id\": \"50685975395-1764015262161\", \"calculated_amount\": 2000, \"backend_receipt_id\": 26, \"conciliation_contract_id\": 125}','2025-11-24 20:14:22','2025-11-24 23:49:31',NULL),(27,40,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50687127185-1764076545244',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687127185-1764076545244\", \"calculated_amount\": 2000, \"backend_receipt_id\": 27, \"conciliation_contract_id\": 101}','2025-11-25 13:15:45','2025-11-25 13:16:32',NULL),(28,39,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50687502916-1764180195774',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687502916-1764180195774\", \"calculated_amount\": 2000, \"backend_receipt_id\": 28, \"conciliation_contract_id\": 100}','2025-11-26 18:03:16','2025-11-26 18:03:35',NULL),(29,41,NULL,NULL,6000.00,'CRC','verified','whatsapp','bot:50686686768-1764189452464',NULL,'{\"months\": 3, \"local_receipt_id\": \"50686686768-1764189452464\", \"calculated_amount\": 6000, \"backend_receipt_id\": 29, \"conciliation_contract_id\": 102}','2025-11-26 20:37:32','2025-11-26 20:38:10',NULL),(30,75,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50687441073-1764261864742',NULL,'{\"months\": 1, \"local_receipt_id\": \"50687441073-1764261864742\", \"calculated_amount\": 2000, \"backend_receipt_id\": 30, \"conciliation_contract_id\": 86}','2025-11-27 16:44:25','2025-11-27 16:44:41',NULL),(31,45,NULL,NULL,3000.00,'CRC','unverified','whatsapp','bot:50662321128-1764297186222',NULL,'{\"months\": 1, \"local_receipt_id\": \"50662321128-1764297186222\", \"backend_receipt_id\": 31}','2025-11-28 02:33:06','2025-12-02 14:52:36','2025-12-02 14:52:36'),(32,47,NULL,NULL,10000.00,'CRC','verified','whatsapp','bot:50660450895-1764365969653',NULL,'{\"months\": 1, \"local_receipt_id\": \"50660450895-1764365969653\", \"calculated_amount\": 10000, \"backend_receipt_id\": 32, \"conciliation_contract_id\": 108}','2025-11-28 21:39:30','2025-11-29 12:43:51',NULL),(33,58,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50672457845-1764367774194',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672457845-1764367774194\", \"calculated_amount\": 2000, \"backend_receipt_id\": 33, \"conciliation_contract_id\": 119}','2025-11-28 22:09:34','2025-11-29 12:44:02',NULL),(34,69,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50671445572-1764420324711',NULL,'{\"months\": 1, \"local_receipt_id\": \"50671445572-1764420324711\", \"calculated_amount\": 2000, \"backend_receipt_id\": 34, \"conciliation_contract_id\": 130}','2025-11-29 12:45:24','2025-11-29 12:46:02',NULL),(35,36,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50671582729-1764453416453',NULL,'{\"months\": 1, \"local_receipt_id\": \"50671582729-1764453416453\", \"calculated_amount\": 2000, \"backend_receipt_id\": 35, \"conciliation_contract_id\": 97}','2025-11-29 21:56:56','2025-11-29 22:55:51',NULL),(36,36,NULL,NULL,2000.00,'CRC','unverified','whatsapp','bot:50671582729-1764453499032',NULL,'{\"months\": 1, \"local_receipt_id\": \"50671582729-1764453499032\", \"backend_receipt_id\": 36}','2025-11-29 21:58:19','2025-12-02 14:52:30','2025-12-02 14:52:30'),(37,54,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50689272975-1764520032357',NULL,'{\"months\": 1, \"local_receipt_id\": \"50689272975-1764520032357\", \"calculated_amount\": 2000, \"backend_receipt_id\": 37, \"conciliation_contract_id\": 115}','2025-11-30 16:27:12','2025-11-30 16:27:57',NULL),(38,31,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50683319122-1764530746985',NULL,'{\"months\": 1, \"local_receipt_id\": \"50683319122-1764530746985\", \"calculated_amount\": 2000, \"backend_receipt_id\": 38, \"conciliation_contract_id\": 92}','2025-11-30 19:25:47','2025-11-30 20:01:44',NULL),(39,70,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50660312134-1764533117836',NULL,'{\"months\": 1, \"local_receipt_id\": \"50660312134-1764533117836\", \"calculated_amount\": 2000, \"backend_receipt_id\": 39, \"conciliation_contract_id\": 131}','2025-11-30 20:05:18','2025-11-30 22:04:09',NULL),(40,30,NULL,NULL,3000.00,'CRC','verified','whatsapp','bot:50685096177-1764545513074',NULL,'{\"months\": 1, \"local_receipt_id\": \"50685096177-1764545513074\", \"calculated_amount\": 3000, \"backend_receipt_id\": 40, \"conciliation_contract_id\": 91}','2025-11-30 23:31:53','2025-12-01 00:39:07',NULL),(41,35,NULL,NULL,7000.00,'CRC','verified','whatsapp','bot:50661151082-1764566979121',NULL,'{\"months\": 1, \"local_receipt_id\": \"50661151082-1764566979121\", \"calculated_amount\": 7000, \"backend_receipt_id\": 41, \"conciliation_contract_id\": 96}','2025-12-01 05:29:39','2025-12-01 15:27:00',NULL),(42,22,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50688974441-1764603555252',NULL,'{\"months\": 1, \"local_receipt_id\": \"50688974441-1764603555252\", \"calculated_amount\": 2000, \"backend_receipt_id\": 42, \"conciliation_contract_id\": 83}','2025-12-01 15:39:15','2025-12-01 15:43:34',NULL),(43,63,NULL,NULL,6000.00,'CRC','verified','whatsapp','bot:50661183344-1764604580092',NULL,'{\"months\": 1, \"local_receipt_id\": \"50661183344-1764604580092\", \"calculated_amount\": 6000, \"backend_receipt_id\": 43, \"conciliation_contract_id\": 124}','2025-12-01 15:56:20','2025-12-01 16:15:32',NULL),(44,70,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50660312134-1764682323652',NULL,'{\"months\": 1, \"local_receipt_id\": \"50660312134-1764682323652\", \"calculated_amount\": 2000, \"backend_receipt_id\": 44, \"conciliation_contract_id\": 131}','2025-12-02 13:32:03','2025-12-02 14:29:32',NULL),(45,82,NULL,NULL,20000.00,'CRC','verified','whatsapp','bot:50683387993-1764689120762',NULL,'{\"months\": 1, \"local_receipt_id\": \"50683387993-1764689120762\", \"calculated_amount\": 20000, \"backend_receipt_id\": 45, \"conciliation_contract_id\": 139}','2025-12-02 15:25:22','2025-12-02 15:26:44',NULL),(46,57,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50663120452-1764729956556',NULL,'{\"months\": 1, \"local_receipt_id\": \"50663120452-1764729956556\", \"calculated_amount\": 2000, \"backend_receipt_id\": 46, \"conciliation_contract_id\": 118}','2025-12-03 02:45:56','2025-12-03 02:52:25',NULL),(47,42,NULL,NULL,10000.00,'CRC','verified','whatsapp','bot:50672057966-1764870777553',NULL,'{\"months\": 1, \"local_receipt_id\": \"50672057966-1764870777553\", \"calculated_amount\": 10000, \"backend_receipt_id\": 47, \"conciliation_contract_id\": 103}','2025-12-04 17:52:57','2025-12-04 18:02:52',NULL),(48,22,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50688974441-1764934139724',NULL,'{\"months\": 1, \"local_receipt_id\": \"50688974441-1764934139724\", \"calculated_amount\": 2000, \"backend_receipt_id\": 48, \"conciliation_contract_id\": 83}','2025-12-05 11:28:59','2025-12-06 01:26:35',NULL),(49,27,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50685782222-1764966302063',NULL,'{\"months\": 1, \"local_receipt_id\": \"50685782222-1764966302063\", \"calculated_amount\": 2000, \"backend_receipt_id\": 49, \"conciliation_contract_id\": 88}','2025-12-05 20:25:02','2025-12-06 01:26:45',NULL),(50,44,NULL,NULL,5000.00,'CRC','verified','whatsapp','bot:50660244291-1765135848031',NULL,'{\"months\": 1, \"local_receipt_id\": \"50660244291-1765135848031\", \"calculated_amount\": 5000, \"backend_receipt_id\": 50, \"conciliation_contract_id\": 105}','2025-12-07 19:30:48','2025-12-07 19:31:20',NULL),(51,21,NULL,NULL,2000.00,'CRC','verified','whatsapp','bot:50683677150-1765136403874',NULL,'{\"months\": 1, \"local_receipt_id\": \"50683677150-1765136403874\", \"calculated_amount\": 2000, \"backend_receipt_id\": 51, \"conciliation_contract_id\": 82}','2025-12-07 19:40:04','2025-12-07 19:42:34',NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`),
  KEY `personal_access_tokens_expires_at_index` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
INSERT INTO `personal_access_tokens` VALUES (1,'App\\Models\\User',1,'bot-token','3b42389e23d9603f64c13c250375c826e81cd7227f755c20caaf3c1541445b5b','[\"*\"]','2025-12-08 16:09:29',NULL,'2025-11-01 20:36:48','2025-12-08 16:09:29'),(2,'App\\Models\\User',1,'cli-test-token','2e4d43efe668212c7bf56935eee6d66a11b65e0b9e76b10cdb9ba9c9deffff66','[\"*\"]','2025-11-15 21:20:14',NULL,'2025-11-15 21:06:24','2025-11-15 21:20:14');
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder_messages`
--

DROP TABLE IF EXISTS `reminder_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `reminder_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `direction` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'text',
  `content` text COLLATE utf8mb4_unicode_ci,
  `whatsapp_message_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `metadata` json DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reminder_messages_reminder_id_foreign` (`reminder_id`),
  KEY `reminder_messages_client_id_foreign` (`client_id`),
  CONSTRAINT `reminder_messages_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reminder_messages_reminder_id_foreign` FOREIGN KEY (`reminder_id`) REFERENCES `reminders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder_messages`
--

LOCK TABLES `reminder_messages` WRITE;
/*!40000 ALTER TABLE `reminder_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminders`
--

DROP TABLE IF EXISTS `reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `contract_id` bigint unsigned NOT NULL,
  `client_id` bigint unsigned NOT NULL,
  `channel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'whatsapp',
  `scheduled_for` datetime NOT NULL,
  `queued_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `acknowledged_at` datetime DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `payload` json DEFAULT NULL,
  `response_payload` json DEFAULT NULL,
  `attempts` tinyint unsigned NOT NULL DEFAULT '0',
  `last_attempt_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `reminders_contract_id_foreign` (`contract_id`),
  KEY `reminders_client_id_foreign` (`client_id`),
  CONSTRAINT `reminders_client_id_foreign` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON DELETE CASCADE,
  CONSTRAINT `reminders_contract_id_foreign` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminders`
--

LOCK TABLES `reminders` WRITE;
/*!40000 ALTER TABLE `reminders` DISABLE KEYS */;
INSERT INTO `reminders` VALUES (134,79,18,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:54','2025-11-20 16:10:54',NULL),(135,80,19,'whatsapp','2025-12-01 00:00:00','2025-11-30 23:30:02','2025-11-30 23:30:02',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:54','2025-12-01 05:30:02',NULL),(136,81,20,'whatsapp','2025-12-17 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:55','2025-11-20 16:10:55',NULL),(137,82,21,'whatsapp','2025-12-02 00:00:00','2025-12-01 23:30:03','2025-12-01 23:30:03',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:56','2025-12-02 05:30:03',NULL),(138,83,22,'whatsapp','2025-12-05 00:00:00','2025-12-04 23:30:07','2025-12-04 23:30:07',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:56','2025-12-05 05:30:07',NULL),(139,84,23,'whatsapp','2025-12-12 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:56','2025-11-20 16:10:56',NULL),(140,85,24,'whatsapp','2025-12-16 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:56','2025-11-20 16:10:56',NULL),(141,86,75,'whatsapp','2025-11-20 00:00:00','2025-11-20 22:11:07','2025-11-20 16:11:07',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:57','2025-11-20 16:11:07',NULL),(142,87,26,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:57','2025-11-20 16:10:57',NULL),(143,88,27,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:00','2025-11-29 23:30:00',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:57','2025-11-30 05:30:00',NULL),(144,89,28,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:58','2025-11-20 16:10:58',NULL),(145,90,29,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:01','2025-11-29 23:30:03',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:58','2025-11-30 05:30:03',NULL),(146,91,30,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:03','2025-11-29 23:30:04',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:58','2025-11-30 05:30:04',NULL),(147,92,31,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:04','2025-11-29 23:30:04',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:59','2025-11-30 05:30:04',NULL),(148,93,32,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:10:59','2025-11-20 16:10:59',NULL),(149,94,33,'whatsapp','2025-12-07 00:00:00','2025-12-06 23:30:10','2025-12-06 23:30:10',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:10:59','2025-12-07 05:30:10',NULL),(150,95,34,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:00','2025-11-20 16:11:00',NULL),(151,96,35,'whatsapp','2025-12-03 00:00:00','2025-12-02 23:30:04','2025-12-02 23:30:05',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:00','2025-12-03 05:30:05',NULL),(152,97,36,'whatsapp','2025-11-29 00:00:00','2025-11-28 23:30:29','2025-11-28 23:30:29',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:00','2025-11-29 05:30:29',NULL),(153,98,37,'whatsapp','2025-12-10 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:01','2025-11-20 16:11:01',NULL),(154,99,38,'whatsapp','2025-12-18 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:01','2025-11-20 16:11:01',NULL),(155,100,39,'whatsapp','2025-11-21 00:00:00','2025-11-21 05:30:08','2025-11-20 23:30:08',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:01','2025-11-20 23:30:08',NULL),(156,101,40,'whatsapp','2025-11-25 00:00:00','2025-11-25 05:30:23','2025-11-24 23:30:24',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:01','2025-11-25 05:30:24',NULL),(157,102,41,'whatsapp','2025-11-26 00:00:00','2025-11-26 05:30:25','2025-11-25 23:30:25',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:02','2025-11-26 05:30:25',NULL),(158,103,42,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:05','2025-11-29 23:30:05',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:02','2025-11-30 05:30:05',NULL),(159,104,43,'whatsapp','2025-12-19 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:02','2025-11-20 16:11:02',NULL),(160,105,44,'whatsapp','2025-12-02 00:00:00','2025-12-01 23:30:04','2025-12-01 23:30:05',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:03','2025-12-02 05:30:05',NULL),(161,106,45,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:06','2025-11-29 23:30:06',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:03','2025-11-30 05:30:06',NULL),(162,107,46,'whatsapp','2025-12-13 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:03','2025-11-20 16:11:03',NULL),(163,108,47,'whatsapp','2025-11-29 00:00:00','2025-11-28 23:30:30','2025-11-28 23:30:31',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:04','2025-11-29 05:30:31',NULL),(164,109,48,'whatsapp','2025-12-11 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:04','2025-11-20 16:11:04',NULL),(165,110,49,'whatsapp','2025-11-20 00:00:00','2025-11-20 22:11:08','2025-11-20 16:11:09',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:04','2025-11-20 16:11:09',NULL),(166,111,50,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:05','2025-11-20 16:11:05',NULL),(167,112,51,'whatsapp','2025-12-18 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:05','2025-11-20 16:11:05',NULL),(168,113,52,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:07','2025-11-29 23:30:07',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:05','2025-11-30 05:30:07',NULL),(169,114,53,'whatsapp','2025-11-22 00:00:00','2025-11-22 05:30:09','2025-11-21 23:30:09',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:06','2025-11-21 23:30:09',NULL),(170,115,54,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:08','2025-11-29 23:30:08',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:06','2025-11-30 05:30:08',NULL),(171,116,55,'whatsapp','2025-12-19 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:06','2025-11-20 16:11:06',NULL),(172,117,56,'whatsapp','2025-12-17 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:07','2025-11-20 16:11:07',NULL),(173,118,57,'whatsapp','2025-12-02 00:00:00','2025-12-01 23:30:06','2025-12-01 23:30:07',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:07','2025-12-02 05:30:07',NULL),(174,119,58,'whatsapp','2025-11-24 00:00:00','2025-11-24 05:30:22','2025-11-23 23:30:23',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:07','2025-11-24 05:30:23',NULL),(175,86,75,'whatsapp','2025-12-26 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-20 16:11:08','2025-11-26 19:57:27',NULL),(176,120,59,'whatsapp','2025-12-05 00:00:00','2025-12-04 23:30:08','2025-12-04 23:30:09',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:08','2025-12-05 05:30:09',NULL),(177,121,60,'whatsapp','2025-12-03 00:00:00','2025-12-02 23:30:06','2025-12-02 23:30:06',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:09','2025-12-03 05:30:06',NULL),(178,122,61,'whatsapp','2025-11-21 00:00:00','2025-11-21 05:30:09','2025-11-20 23:30:09',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:09','2025-11-20 23:30:09',NULL),(179,110,49,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-20 16:11:09','2025-12-04 17:48:08',NULL),(180,123,62,'whatsapp','2025-12-14 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"4000.00\"}',NULL,0,NULL,'2025-11-20 16:11:10','2025-11-21 12:06:39',NULL),(181,124,63,'whatsapp','2025-12-01 00:00:00','2025-11-30 23:30:03','2025-11-30 23:30:03',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:10','2025-12-01 05:30:03',NULL),(182,125,64,'whatsapp','2025-11-23 00:00:00','2025-11-23 05:30:10','2025-11-22 23:30:11',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:10','2025-11-22 23:30:11',NULL),(183,126,65,'whatsapp','2025-12-16 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL),(184,127,66,'whatsapp','2025-12-09 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL),(185,128,67,'whatsapp','2025-12-16 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:11','2025-11-20 16:11:11',NULL),(186,129,68,'whatsapp','2025-12-16 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:12','2025-11-20 16:11:12',NULL),(187,130,69,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:09','2025-11-29 23:30:09',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:12','2025-11-30 05:30:09',NULL),(188,131,70,'whatsapp','2025-11-25 00:00:00','2025-11-25 05:30:25','2025-11-24 23:30:26',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:12','2025-11-25 05:30:26',NULL),(189,132,71,'whatsapp','2025-12-15 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:12','2025-11-20 16:11:12',NULL),(190,133,72,'whatsapp','2025-11-30 00:00:00','2025-11-29 23:30:10','2025-11-29 23:30:10',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:13','2025-11-30 05:30:10',NULL),(191,134,73,'whatsapp','2025-11-24 00:00:00','2025-11-24 05:30:24','2025-11-23 23:30:26',NULL,'sent',NULL,NULL,1,NULL,'2025-11-20 16:11:13','2025-11-24 05:30:26',NULL),(192,135,74,'whatsapp','2025-12-14 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-20 16:11:13','2025-11-20 16:11:13',NULL),(193,100,39,'whatsapp','2025-12-21 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-20 23:30:09','2025-11-20 23:30:09',NULL),(194,122,61,'whatsapp','2025-12-21 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-20 23:30:10','2025-11-20 23:30:10',NULL),(195,136,79,'whatsapp','2025-11-21 00:00:00','2025-11-21 20:53:03','2025-11-21 14:53:05',NULL,'sent',NULL,NULL,1,NULL,'2025-11-21 14:53:01','2025-11-21 14:53:05',NULL),(196,136,79,'whatsapp','2025-12-21 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-21 14:53:05','2025-11-21 14:53:06',NULL),(197,137,80,'whatsapp','2025-12-21 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-11-21 18:39:34','2025-11-21 18:39:34',NULL),(198,114,53,'whatsapp','2025-12-22 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-21 23:30:10','2025-11-21 23:30:10',NULL),(199,125,64,'whatsapp','2025-12-23 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-22 23:30:11','2025-11-22 23:30:11',NULL),(200,119,58,'whatsapp','2025-12-24 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-24 05:30:24','2025-11-24 05:30:24',NULL),(201,134,73,'whatsapp','2025-12-24 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-24 05:30:26','2025-11-24 05:30:27',NULL),(202,101,40,'whatsapp','2025-12-25 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-25 05:30:25','2025-11-25 05:30:25',NULL),(203,131,70,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-25 05:30:26','2025-11-30 20:03:02',NULL),(204,138,81,'whatsapp','2025-11-25 00:00:00','2025-11-25 18:02:24','2025-11-25 12:02:25',NULL,'sent',NULL,NULL,1,NULL,'2025-11-25 18:02:15','2025-11-25 18:02:25',NULL),(205,138,81,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-25 18:02:25','2025-12-04 17:48:13',NULL),(206,102,41,'whatsapp','2025-12-26 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-26 05:30:25','2025-11-26 05:30:25',NULL),(207,86,75,'whatsapp','2025-12-26 00:00:00',NULL,NULL,NULL,'pending','[]',NULL,0,NULL,'2025-11-26 19:51:15','2025-11-26 19:57:27',NULL),(208,86,75,'whatsapp','2025-11-26 13:57:08','2025-11-26 13:57:26','2025-11-26 13:57:26',NULL,'sent','[]',NULL,1,NULL,'2025-11-26 19:57:11','2025-11-26 19:57:26',NULL),(209,86,75,'whatsapp','2025-12-26 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-26 19:57:26','2025-11-26 19:57:27',NULL),(210,102,41,'whatsapp','2025-11-26 14:34:40','2025-11-26 14:34:56','2025-11-26 14:34:56',NULL,'sent','[]',NULL,1,NULL,'2025-11-26 20:34:44','2025-11-26 20:34:56',NULL),(211,102,41,'whatsapp','2025-12-26 14:34:40',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-26 20:34:56','2025-11-26 20:34:56',NULL),(212,110,49,'whatsapp','2025-11-26 14:35:17','2025-11-26 14:35:26','2025-11-26 14:35:26',NULL,'sent','[]',NULL,1,NULL,'2025-11-26 20:35:21','2025-11-26 20:35:26',NULL),(213,110,49,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-26 20:35:26','2025-12-04 17:48:08',NULL),(214,97,36,'whatsapp','2025-12-29 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-29 05:30:29','2025-11-29 05:30:30',NULL),(215,108,47,'whatsapp','2025-12-29 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"10000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-29 05:30:31','2025-11-29 05:30:32',NULL),(216,88,27,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:01','2025-12-04 17:47:08',NULL),(217,90,29,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:03','2025-11-30 05:30:03',NULL),(218,91,30,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:04','2025-11-30 05:30:04',NULL),(219,92,31,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:05','2025-11-30 05:30:05',NULL),(220,103,42,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"10000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:06','2025-12-04 17:47:39',NULL),(221,106,45,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:06','2025-12-04 17:47:42',NULL),(222,113,52,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:07','2025-12-04 17:48:10',NULL),(223,115,54,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:08','2025-11-30 05:30:09',NULL),(224,130,69,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:09','2025-11-30 05:30:10',NULL),(225,133,72,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 05:30:10','2025-11-30 05:30:11',NULL),(226,138,81,'whatsapp','2025-11-30 14:02:31','2025-11-30 14:02:31','2025-11-30 14:02:31',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:02:28','2025-11-30 20:02:31',NULL),(227,138,81,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:02:32','2025-12-04 17:48:13',NULL),(228,131,70,'whatsapp','2025-11-30 14:02:50','2025-11-30 14:03:01','2025-11-30 14:03:01',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:02:47','2025-11-30 20:03:01',NULL),(229,131,70,'whatsapp','2025-12-30 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:03:02','2025-11-30 20:03:02',NULL),(230,113,52,'whatsapp','2025-11-30 14:03:06','2025-11-30 14:03:31','2025-11-30 14:03:31',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:02','2025-11-30 20:03:31',NULL),(231,110,49,'whatsapp','2025-11-30 14:03:20','2025-11-30 14:03:31','2025-11-30 14:03:32',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:16','2025-11-30 20:03:32',NULL),(232,106,45,'whatsapp','2025-11-30 14:03:29','2025-11-30 14:03:33','2025-11-30 14:03:34',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:25','2025-11-30 20:03:34',NULL),(233,113,52,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:03:31','2025-12-04 17:48:10',NULL),(234,103,42,'whatsapp','2025-11-30 14:03:36','2025-11-30 14:04:01','2025-11-30 14:04:02',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:32','2025-11-30 20:04:02',NULL),(235,110,49,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:03:33','2025-12-04 17:48:08',NULL),(236,106,45,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:03:34','2025-12-04 17:47:42',NULL),(237,91,30,'whatsapp','2025-11-30 14:03:52','2025-11-30 14:04:02','2025-11-30 14:04:03',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:48','2025-11-30 20:04:03',NULL),(238,90,29,'whatsapp','2025-11-30 14:04:00','2025-11-30 14:04:03','2025-11-30 14:04:03',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:03:56','2025-11-30 20:04:03',NULL),(239,103,42,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"10000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:04:02','2025-12-04 17:47:39',NULL),(240,91,30,'whatsapp','2025-12-30 14:03:52',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:04:03','2025-11-30 20:04:03',NULL),(241,90,29,'whatsapp','2025-12-30 14:04:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:04:04','2025-11-30 20:04:04',NULL),(242,88,27,'whatsapp','2025-11-30 14:04:12','2025-11-30 14:04:31','2025-11-30 14:04:31',NULL,'sent','[]',NULL,1,NULL,'2025-11-30 20:04:08','2025-11-30 20:04:31',NULL),(243,88,27,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-11-30 20:04:31','2025-12-04 17:47:08',NULL),(244,80,19,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-01 05:30:02','2025-12-04 17:46:37',NULL),(245,124,63,'whatsapp','2026-01-01 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"6000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-01 05:30:04','2025-12-01 05:30:04',NULL),(246,82,21,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-02 05:30:03','2025-12-04 17:47:07',NULL),(247,105,44,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"5000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-02 05:30:05','2025-12-04 17:47:41',NULL),(248,118,57,'whatsapp','2026-01-02 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-02 05:30:07','2025-12-02 05:30:08',NULL),(249,139,82,'whatsapp','2026-01-01 00:00:00',NULL,NULL,NULL,'pending',NULL,NULL,0,NULL,'2025-12-02 15:26:30','2025-12-02 15:26:30',NULL),(250,96,35,'whatsapp','2026-01-03 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"7000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-03 05:30:05','2025-12-03 05:30:06',NULL),(251,121,60,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-03 05:30:07','2025-12-04 17:48:12',NULL),(252,80,19,'whatsapp','2025-12-04 11:46:34','2025-12-04 11:46:36','2025-12-04 11:46:36',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:46:31','2025-12-04 17:46:36',NULL),(253,80,19,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:46:37','2025-12-04 17:46:37',NULL),(254,82,21,'whatsapp','2025-12-04 11:46:50','2025-12-04 11:47:06','2025-12-04 11:47:06',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:46:47','2025-12-04 17:47:06',NULL),(255,88,27,'whatsapp','2025-12-04 11:46:59','2025-12-04 11:47:07','2025-12-04 11:47:08',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:46:56','2025-12-04 17:47:08',NULL),(256,82,21,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:47:07','2025-12-04 17:47:07',NULL),(257,88,27,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:47:08','2025-12-04 17:47:08',NULL),(258,103,42,'whatsapp','2025-12-04 11:47:14','2025-12-04 11:47:36','2025-12-04 11:47:38',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:11','2025-12-04 17:47:38',NULL),(259,105,44,'whatsapp','2025-12-04 11:47:24','2025-12-04 11:47:39','2025-12-04 11:47:40',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:21','2025-12-04 17:47:40',NULL),(260,106,45,'whatsapp','2025-12-04 11:47:33','2025-12-04 11:47:41','2025-12-04 11:47:41',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:30','2025-12-04 17:47:41',NULL),(261,110,49,'whatsapp','2025-12-04 11:47:41','2025-12-04 11:48:06','2025-12-04 11:48:07',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:38','2025-12-04 17:48:07',NULL),(262,103,42,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"10000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:47:38','2025-12-04 17:47:39',NULL),(263,105,44,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"5000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:47:40','2025-12-04 17:47:41',NULL),(264,106,45,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:47:41','2025-12-04 17:47:42',NULL),(265,113,52,'whatsapp','2025-12-04 11:47:49','2025-12-04 11:48:08','2025-12-04 11:48:09',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:46','2025-12-04 17:48:09',NULL),(266,121,60,'whatsapp','2025-12-04 11:47:55','2025-12-04 11:48:10','2025-12-04 11:48:11',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:47:52','2025-12-04 17:48:11',NULL),(267,138,81,'whatsapp','2025-12-04 11:48:06','2025-12-04 11:48:13','2025-12-04 11:48:13',NULL,'sent','[]',NULL,1,NULL,'2025-12-04 17:48:03','2025-12-04 17:48:13',NULL),(268,110,49,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:48:07','2025-12-04 17:48:08',NULL),(269,113,52,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:48:09','2025-12-04 17:48:10',NULL),(270,121,60,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:48:12','2025-12-04 17:48:12',NULL),(271,138,81,'whatsapp','2026-01-04 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"3000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-04 17:48:13','2025-12-04 17:48:13',NULL),(272,83,22,'whatsapp','2026-01-05 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"2000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-05 05:30:07','2025-12-05 05:30:08',NULL),(273,120,59,'whatsapp','2026-01-05 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"4000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-05 05:30:09','2025-12-05 05:30:09',NULL),(274,94,33,'whatsapp','2026-01-07 00:00:00',NULL,NULL,NULL,'pending','{\"amount\": \"5000.00\", \"recurrence\": \"monthly\"}',NULL,0,NULL,'2025-12-07 05:30:10','2025-12-07 05:30:11',NULL);
/*!40000 ALTER TABLE `reminders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Fabián','test@example.com','2025-11-15 20:21:12','$2y$12$SID7OVV7mZpc8RSs.sqKv.sdjGeiw/AU1zFVeryEG0AJ1dVHpnOG6','th0kTQlZLBGnv5V0eYjb2BE7oK1sZCdxPbpktAVslR2G2f4fBtnLGluOvobi','2025-11-01 05:19:30','2025-11-21 15:16:47');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'ticobot'
--

--
-- Dumping routines for database 'ticobot'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 10:09:42
